$(() => {
    alert("bonjour");
});