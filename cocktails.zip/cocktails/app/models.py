from django.db import models


# Create your models here.

class Question(models.Model):
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')


class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)


class Recipe(models.Model):
    title = models.CharField(max_length=200, blank=True, null=True)
    summary = models.CharField(max_length=200, blank=True, null=True)
    content = models.TextField(blank=True, null=True)

    def __str__(self):
        if self.title != "":
            return f"{self.title}"
        return "? (no title) ?"
        # return self.title or "? (no title) ?"


class Ingredient(models.Model):
    name_singular = models.CharField(max_length=200, blank=True, null=True)
    name_plural = models.CharField(max_length=200, blank=True, null=True)

    def __str__(self):
        return f"{self.name_singular} / {self.name_plural}"


class Unit(models.Model):
    name = models.CharField(max_length=200, blank=True, null=True)

    def __str__(self):
        return self.name or "? (no name) ?"


class Tag(models.Model):
    name = models.CharField(max_length=200, blank=True, null=True)
    """"
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE)
    """
    def __str__(self):
        return f"{self.name}"


class RecipeTag(models.Model):
    tag = models.ForeignKey(Tag, on_delete=models.CASCADE)
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.recipe} / {self.tag}"


class RecipeIngredientUnit(models.Model):
    unit = models.ForeignKey(Unit, on_delete=models.CASCADE)
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE)
    ingredient = models.ForeignKey(Ingredient, on_delete=models.CASCADE)
    value = models.FloatField(default=1.0)
    unit_is_displayed = models.BooleanField(default=True)

    def __str__(self):
        if self.unit_is_displayed:
            return f"{self.recipe} / {self.value} {self.unit} / {self.ingredient}"
        return f"{self.recipe} / {self.value} {self.ingredient} / {self.unit}"

